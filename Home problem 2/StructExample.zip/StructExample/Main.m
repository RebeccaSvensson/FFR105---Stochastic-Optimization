minChromosomeLength = 3;
maxChromosomeLength = 10;
populationSize = 10;

population = InitializePopulation(populationSize,minChromosomeLength,maxChromosomeLength);


population(1).Chromosome
population(2).Chromosome
population(3).Chromosome

%% etc...


