function population = InitializePopulation(populationSize,minChromosomeLength,maxChromosomeLength);

population = [];
for i = 1:populationSize
 chromosomeLength = minChromosomeLength + fix(rand*(maxChromosomeLength-minChromosomeLength+1));
 tmpChromosome = fix(2*rand(chromosomeLength,1));
 tmpIndividual = struct('Chromosome',tmpChromosome);
 population = [population tmpIndividual];
end